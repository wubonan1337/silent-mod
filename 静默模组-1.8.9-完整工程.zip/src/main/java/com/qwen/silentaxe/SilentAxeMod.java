package com.qwen.silentaxe;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.lwjgl.input.Keyboard;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/**
 * 静默模组主类（Minecraft 1.8.9 Forge）
 *
 * 功能：
 * 1. 服务器模式：攻击瞬间静默发送切斧数据包，服务器按斧子结算伤害，客户端手持物品不变（真实静默切斧）。
 * 2. 单人/局域网模式：手持任意物品打出斧子伤害；持剑时剑伤+斧伤叠加；命中额外损耗目标护甲耐久（破甲加速）。
 * 3. 按 L 打开「静默」菜单，开关真实生效，状态持久化保存。
 */
@Mod(modid = SilentAxeMod.MODID, name = "静默", version = SilentAxeMod.VERSION,
        clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class SilentAxeMod {

    public static final String MODID = "silentaxe";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static SilentAxeMod instance;

    /** 功能总开关（volatile：单人模式下客户端线程与内置服务器线程都会读） */
    public static volatile boolean enabled = false;

    /** 菜单按键，强制固定为 L */
    public static KeyBinding menuKey;

    private static File configFile;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        configFile = new File(event.getModConfigurationDirectory(), "silentaxe.properties");
        loadConfig();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        menuKey = new KeyBinding("打开静默菜单", Keyboard.KEY_L, "静默模组");
        ClientRegistry.registerKeyBinding(menuKey);

        ClientCombatHandler clientHandler = new ClientCombatHandler();
        MinecraftForge.EVENT_BUS.register(clientHandler);
        FMLCommonHandler.instance().bus().register(clientHandler);

        MinecraftForge.EVENT_BUS.register(new ServerEnhanceHandler());
    }

    public static void loadConfig() {
        try {
            if (configFile != null && configFile.exists()) {
                Properties props = new Properties();
                FileInputStream in = new FileInputStream(configFile);
                props.load(in);
                in.close();
                enabled = Boolean.parseBoolean(props.getProperty("enabled", "false"));
            }
        } catch (Exception ignored) {
        }
    }

    public static void saveConfig() {
        try {
            if (configFile == null) return;
            configFile.getParentFile().mkdirs();
            Properties props = new Properties();
            props.setProperty("enabled", String.valueOf(enabled));
            FileOutputStream out = new FileOutputStream(configFile);
            props.store(out, "SilentAxe config");
            out.close();
        } catch (Exception ignored) {
        }
    }

    /** 当前是否处于单人/局域网自建（内置服务器）环境 */
    public static boolean isIntegrated() {
        Minecraft mc = Minecraft.getMinecraft();
        return mc != null && mc.isIntegratedServerRunning();
    }
}
