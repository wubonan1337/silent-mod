package com.qwen.silentaxe;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.opengl.GL11;

/**
 * 「静默」功能菜单：按 L 打开。
 * 单功能开关 + 实时状态（模式 / 斧子检测 / 伤害预览），开关真实控制战斗逻辑并持久化。
 */
public class GuiSilentMenu extends GuiScreen {

    private static final int PANEL_W = 240;
    private static final int PANEL_H = 150;
    private static final int ACCENT = 0xFF39C5BB;
    private static final int PANEL_BG = 0xF012141C;
    private static final int BORDER = 0xFF2A2E3F;

    private GuiButton toggleButton;
    private int panelX;
    private int panelY;

    @Override
    public void initGui() {
        panelX = (this.width - PANEL_W) / 2;
        panelY = (this.height - PANEL_H) / 2;
        this.buttonList.clear();
        toggleButton = new GuiButton(0, panelX + 20, panelY + 40, PANEL_W - 40, 24, toggleText());
        this.buttonList.add(toggleButton);
    }

    private String toggleText() {
        return SilentAxeMod.enabled ? "静默：§a开启" : "静默：§c关闭";
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 0) {
            SilentAxeMod.enabled = !SilentAxeMod.enabled;
            SilentAxeMod.saveConfig();
            button.displayString = toggleText();
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        // 面板
        drawRect(panelX - 1, panelY - 1, panelX + PANEL_W + 1, panelY + PANEL_H + 1, BORDER);
        drawRect(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, PANEL_BG);
        drawRect(panelX, panelY, panelX + PANEL_W, panelY + 2, ACCENT);

        // 标题（放大 1.5 倍）
        GL11.glPushMatrix();
        GL11.glScalef(1.5F, 1.5F, 1.5F);
        this.fontRendererObj.drawStringWithShadow("静默",
                (panelX + PANEL_W / 2) / 1.5F - this.fontRendererObj.getStringWidth("静默") / 2F,
                (panelY + 10) / 1.5F, ACCENT);
        GL11.glPopMatrix();

        super.drawScreen(mouseX, mouseY, partialTicks);

        // 状态区
        int y = panelY + 74;
        boolean integrated = SilentAxeMod.isIntegrated();
        String mode = integrated ? "§a单人增强 §7(伤害+叠加+破甲全生效)" : "§e服务器模式 §7(真实静默切斧)";
        this.fontRendererObj.drawStringWithShadow("模式：" + mode, panelX + 20, y, 0xFFFFFF);
        y += 14;

        String axeDesc = null;
        if (this.mc.thePlayer != null) {
            AxeHelper.AxeInfo info = integrated
                    ? AxeHelper.findBestInventoryAxe(this.mc.thePlayer.inventory)
                    : AxeHelper.findBestHotbarAxe(this.mc.thePlayer.inventory);
            axeDesc = AxeHelper.describe(info);
        }
        if (axeDesc != null) {
            this.fontRendererObj.drawStringWithShadow("斧子：§b" + axeDesc, panelX + 20, y, 0xFFFFFF);
        } else {
            String hint = integrated ? "物品栏里没有斧子" : "快捷栏里没有斧子";
            this.fontRendererObj.drawStringWithShadow("斧子：§c" + hint, panelX + 20, y, 0xFFFFFF);
        }
        y += 14;

        String effect = integrated
                ? "持剑=剑伤+斧伤 · 空手/他物=斧伤 · 破甲x3"
                : "攻击瞬间自动按斧子结算，手持不变";
        this.fontRendererObj.drawStringWithShadow("§7" + effect, panelX + 20, y, 0xAAAAAA);

        this.drawCenteredString(this.fontRendererObj, "§8按 L 或 ESC 关闭", this.width / 2, panelY + PANEL_H - 14, 0x888888);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
