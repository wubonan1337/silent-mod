package com.qwen.silentaxe;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * 内置服务器（单人/局域网自建）伤害增强：
 * - 空手/持非武器：本次伤害至少为物品栏中最强斧子的伤害（拿什么都能打出斧伤）。
 * - 持剑：剑伤 + 斧伤叠加（含双方锋利附魔，剑的部分由原版结算，这里补上斧子部分）。
 * - 持斧：原版已按斧子结算，不重复加伤。
 * - 破甲加速：命中后对目标每件护甲额外造成「斧子伤害值」点耐久损耗（约为原版的 3 倍速破甲），
 *   耐久损耗走原版 damageItem，尊重耐久附魔。
 *
 * 仅在内置服务器生效（伤害由服务器结算，远程服务器无法用客户端模组改伤害）。
 */
public class ServerEnhanceHandler {

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        if (!SilentAxeMod.enabled) return;
        EntityLivingBase target = event.entityLivingBase;
        if (target.worldObj.isRemote) return;
        if (!SilentAxeMod.isIntegrated()) return;
        if (!(event.source.getEntity() instanceof EntityPlayer)) return;
        // 只处理玩家直接攻击（含弹射物以外的近战），排除摔落/火焰等间接伤害
        if (!"player".equals(event.source.damageType)) return;

        EntityPlayer attacker = (EntityPlayer) event.source.getEntity();
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || !attacker.getUniqueID().equals(mc.thePlayer.getUniqueID())) return;

        AxeHelper.AxeInfo axe = AxeHelper.findBestInventoryAxe(attacker.inventory);
        if (axe == null) return;

        ItemStack held = attacker.inventory.getCurrentItem();
        if (held != null && held.getItem() instanceof ItemAxe) {
            // 手里就是斧子：原版已结算斧伤，只做破甲加速
        } else if (held != null && held.getItem() instanceof ItemSword) {
            // 剑 + 斧 叠加
            event.ammount += axe.damage;
        } else {
            // 空手或其他物品：至少打出斧子伤害
            event.ammount = Math.max(event.ammount, axe.damage);
        }

        // 破甲加速：目标每件护甲额外损耗耐久
        int shred = Math.max(1, Math.round(axe.damage));
        for (int slot = 1; slot <= 4; slot++) {
            ItemStack armor = target.getEquipmentInSlot(slot);
            if (armor != null && armor.getItem() instanceof ItemArmor && armor.isItemStackDamageable()) {
                armor.damageItem(shred, attacker);
            }
        }
    }
}
