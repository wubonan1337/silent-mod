package com.qwen.silentaxe;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * 客户端战斗处理：
 * - 服务器模式：攻击瞬间发送「切到斧子」数据包，让服务器按斧子结算本次攻击，
 *   攻击包发出后立刻在本 tick 末发送「切回原槽位」数据包。客户端手持物品全程不变，视觉完全静默。
 * - 单人/局域网模式：不走数据包伪装（由 ServerEnhanceHandler 在内置服务器直接增强伤害）。
 * - L 键菜单（强制固定 L）、HUD 状态提示。
 */
public class ClientCombatHandler {

    /** 待恢复的原快捷栏槽位；-1 表示无 */
    private int pendingRestoreSlot = -1;

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (!SilentAxeMod.enabled || mc.thePlayer == null || mc.getNetHandler() == null) return;
        if (event.entityPlayer != mc.thePlayer) return;
        if (!(event.target instanceof EntityLivingBase)) return;
        // 单人/局域网：由内置服务器增强伤害，不做切斧伪装
        if (SilentAxeMod.isIntegrated()) return;

        AxeHelper.AxeInfo axe = AxeHelper.findBestHotbarAxe(mc.thePlayer.inventory);
        if (axe == null) return;
        int current = mc.thePlayer.inventory.currentItem;
        if (current == axe.slot) return; // 手里已经是斧子

        // 静默切斧：只发数据包，不改客户端手持槽位
        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(axe.slot));
        pendingRestoreSlot = current;
        // 原版攻击包(C02)在本事件之后由游戏发出，服务器收到的顺序：切斧 -> 攻击 -> 切回
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        Minecraft mc = Minecraft.getMinecraft();

        if (event.phase == TickEvent.Phase.START) {
            // 强制菜单键为 L：即使被改掉也立刻改回
            if (SilentAxeMod.menuKey != null && SilentAxeMod.menuKey.getKeyCode() != Keyboard.KEY_L) {
                SilentAxeMod.menuKey.setKeyCode(Keyboard.KEY_L);
            }
            return;
        }

        // END 阶段：攻击包已发出，切回原槽位
        if (pendingRestoreSlot >= 0 && mc.thePlayer != null && mc.getNetHandler() != null) {
            mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(pendingRestoreSlot));
        }
        pendingRestoreSlot = -1;
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (SilentAxeMod.menuKey == null || mc.theWorld == null) return;
        while (SilentAxeMod.menuKey.isPressed()) {
            mc.displayGuiScreen(new GuiSilentMenu());
        }
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.TEXT) return;
        if (!SilentAxeMod.enabled) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen instanceof GuiSilentMenu) return;
        String mode = SilentAxeMod.isIntegrated() ? "增强" : "切斧";
        mc.fontRendererObj.drawStringWithShadow("静默 §a开 §7[" + mode + "]", 4, 4, 0xFFFFFF);
    }
}
