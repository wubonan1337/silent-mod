package com.qwen.silentaxe;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;

/**
 * 斧子检索与伤害计算工具。
 * 伤害口径：斧子基础攻击伤害 + 锋利附魔加成（1.8 机制：每级锋利 +1.25）。
 */
public final class AxeHelper {

    public static class AxeInfo {
        public final int slot;          // 快捷栏槽位（0-8）；-1 表示不在快捷栏
        public final ItemStack stack;
        public final float damage;

        AxeInfo(int slot, ItemStack stack, float damage) {
            this.slot = slot;
            this.stack = stack;
            this.damage = damage;
        }
    }

    private AxeHelper() {
    }

    /** 计算一把斧子的实际攻击伤害（含锋利） */
    public static float axeDamage(ItemStack stack) {
        if (stack == null || !(stack.getItem() instanceof ItemAxe)) return 0F;
        float base = ((ItemTool) stack.getItem()).getDamageVsEntity();
        int sharp = EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, stack);
        return base + 1.25F * sharp;
    }

    /**
     * 在快捷栏（0-8）中寻找伤害最高的斧子。
     * 服务器模式的静默切斧只能用快捷栏内的斧子（原版切换机制限制）。
     */
    public static AxeInfo findBestHotbarAxe(InventoryPlayer inv) {
        AxeInfo best = null;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.mainInventory[i];
            if (stack != null && stack.getItem() instanceof ItemAxe) {
                float dmg = axeDamage(stack);
                if (best == null || dmg > best.damage) {
                    best = new AxeInfo(i, stack, dmg);
                }
            }
        }
        return best;
    }

    /**
     * 在整个物品栏（含背包 9-35）中寻找伤害最高的斧子。
     * 单人/局域网模式的伤害增强由内置服务器直接结算，背包里的斧子也能生效。
     */
    public static AxeInfo findBestInventoryAxe(InventoryPlayer inv) {
        AxeInfo best = null;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inv.mainInventory[i];
            if (stack != null && stack.getItem() instanceof ItemAxe) {
                float dmg = axeDamage(stack);
                if (best == null || dmg > best.damage) {
                    best = new AxeInfo(i < 9 ? i : -1, stack, dmg);
                }
            }
        }
        return best;
    }

    /** 斧子显示名（用于菜单状态行） */
    public static String describe(AxeInfo info) {
        if (info == null) return null;
        String name = info.stack.getDisplayName();
        int sharp = EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, info.stack);
        StringBuilder sb = new StringBuilder(name);
        if (sharp > 0) sb.append(" 锋利").append(sharp);
        sb.append(" · ").append(String.format("%.1f", info.damage)).append("伤害");
        return sb.toString();
    }
}
