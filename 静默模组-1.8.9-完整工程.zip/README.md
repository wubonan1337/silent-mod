# 静默模组 (SilentAxe) - Minecraft 1.8.9

## 功能

- **静默切斧**：攻击时自动切换到斧子造成伤害，手持物品不变（服务器真实生效）
- **伤害增强**：持剑时叠加斧子伤害，空手/其他物品按斧子伤害结算（单人/局域网）
- **破甲加速**：命中时对目标护甲造成额外耐久损耗
- **L 键菜单**：按 L 打开「静默」功能菜单，开关功能并显示状态

## 构建方法

### 方法一：GitHub Actions（推荐，手机端可用）

1. 在 GitHub 创建一个新仓库（如 `silent-axe-mod`）
2. 上传整个项目文件夹的所有文件
3. 推送后 GitHub 会自动编译
4. 进入 Actions 页面，下载 `SilentAxe-Mod` 压缩包
5. 解压得到 `静默-1.0.0.jar`

### 方法二：本地电脑编译

需要安装 JDK 8，然后运行：

```bash
./gradlew build
```

产物在 `build/libs/` 目录下。

## 安装方法（FCL 手机启动器）

1. 将 `静默-1.0.0.jar` 复制到 FCL 的 `mods` 文件夹
2. 确保游戏版本是 **1.8.9 Forge**
3. **Java 选择 Java 8**（FCL 内置，无需额外安装）
4. 在 FCL 按键布局中添加一个映射为 **L** 的虚拟按键
5. 启动游戏，按 L 打开菜单，开启「静默」功能

## 重要说明

- **Java 版本**：1.8.9 Forge 必须用 Java 8，选 Java 21 会导致游戏无法启动
- **FCL 的 Java 是按版本独立的**：1.8.9 用 Java 8 不影响其他版本的模组
- **服务器模式**：在多人服务器中，模组发送真实切斧数据包（有反作弊检测风险）
- **单人模式**：伤害增强由内置服务器直接结算，完全安全

## 源码结构

```
src/main/java/com/qwen/silentaxe/
├── SilentAxeMod.java          # 模组主类，注册事件和按键
├── AxeHelper.java              # 斧子搜索和伤害计算
├── ClientCombatHandler.java    # 客户端战斗处理（静默切斧、HUD、菜单按键）
├── ServerEnhanceHandler.java   # 服务端伤害增强（单人/局域网）
└── GuiSilentMenu.java          # 「静默」菜单界面
```

## 许可证

本项目仅供学习交流使用。
